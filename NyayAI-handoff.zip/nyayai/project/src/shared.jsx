// NyayAI — Shared primitives (nav, footer, language ribbon)

const INDIAN_LANGS = [
  { word: 'न्याय', note: 'Nyāya — Hindi' },
  { word: 'நீதி', note: 'Nīti — Tamil' },
  { word: 'ন্যায়', note: 'Nyāẏa — Bengali' },
  { word: 'న్యాయం', note: 'Nyāyaṁ — Telugu' },
  { word: 'ਨਿਆਂ', note: 'Niā̃ — Punjabi' },
  { word: 'ન્યાય', note: 'Nyāy — Gujarati' },
  { word: 'ನ್ಯಾಯ', note: 'Nyāya — Kannada' },
  { word: 'നീതി', note: 'Nīti — Malayalam' },
  { word: 'न्याय', note: 'Nyāya — Marathi' },
  { word: 'انصاف', note: 'Insāf — Urdu' },
  { word: 'ନ୍ୟାୟ', note: 'Nyāẏa — Odia' },
  { word: 'Justice', note: 'English' },
];

function Logo() {
  return (
    <a href="#home" className="brand" onClick={(e) => { e.preventDefault(); window.navigate('home'); }}>
      <div className="brand-mark"><span style={{ fontStyle: 'italic' }}>N</span></div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <span className="brand-word">NyayAI</span>
        <span className="brand-sub">Legal Intelligence</span>
      </div>
    </a>
  );
}

function Nav({ route }) {
  const links = [
    { id: 'home', label: 'Home' },
    { id: 'features', label: 'Features' },
    { id: 'pricing', label: 'Pricing' },
    { id: 'about', label: 'About' },
  ];
  return (
    <nav className="nav">
      <div className="container">
        <div className="nav-inner">
          <Logo />
          <div className="nav-links">
            {links.map(l => (
              <a
                key={l.id}
                href={`#${l.id}`}
                className={`nav-link ${route === l.id ? 'active' : ''}`}
                onClick={(e) => { e.preventDefault(); window.navigate(l.id); }}
              >
                {l.label}
              </a>
            ))}
            <div className="nav-cta">
              <button className="btn btn-ghost">Sign in</button>
              <button className="btn btn-primary" onClick={() => window.navigate('pricing')}>
                Request access
                <span style={{ fontSize: 14, lineHeight: 0 }}>→</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}

function LangRibbon() {
  const doubled = [...INDIAN_LANGS, ...INDIAN_LANGS];
  return (
    <div className="lang-ribbon">
      <div className="lang-ribbon-track">
        {doubled.map((l, i) => (
          <span key={i} className="lang-word">
            <span>{l.word}</span>
            <span className="mono">{l.note}</span>
            <span style={{ color: 'var(--ink-4)', fontFamily: 'var(--mono)', fontSize: 12 }}>—</span>
          </span>
        ))}
      </div>
    </div>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div>
            <Logo />
            <p className="footer-brand-p">
              India's legal operating system. Built on retrieval-grounded reasoning over statutes, case law, and practitioner workflows.
            </p>
            <div className="footer-langs" style={{ fontFamily: 'var(--serif)', fontStyle: 'italic' }}>
              <span>न्याय</span>
              <span style={{ fontFamily: 'var(--tamil)' }}>நீதி</span>
              <span style={{ fontFamily: 'var(--bengali)' }}>ন্যায়</span>
              <span style={{ fontFamily: 'var(--urdu)' }}>انصاف</span>
            </div>
          </div>
          <div className="footer-col">
            <h4>Product</h4>
            <a href="#" onClick={(e) => { e.preventDefault(); window.navigate('features'); }}>Features</a>
            <a href="#" onClick={(e) => { e.preventDefault(); window.navigate('pricing'); }}>Pricing</a>
            <a href="#">Changelog</a>
            <a href="#">API Docs</a>
            <a href="#">Status</a>
          </div>
          <div className="footer-col">
            <h4>Practice</h4>
            <a href="#">Research</a>
            <a href="#">Drafting</a>
            <a href="#">Compliance</a>
            <a href="#">Case Strategy</a>
            <a href="#">Litigation</a>
          </div>
          <div className="footer-col">
            <h4>Company</h4>
            <a href="#" onClick={(e) => { e.preventDefault(); window.navigate('about'); }}>About</a>
            <a href="#">Research Notes</a>
            <a href="#">Careers</a>
            <a href="#">Press</a>
            <a href="#">Contact</a>
          </div>
          <div className="footer-col">
            <h4>Legal</h4>
            <a href="#">Terms of Service</a>
            <a href="#">Privacy</a>
            <a href="#">Data Handling</a>
            <a href="#">Bar Compliance</a>
            <a href="#">Responsible AI</a>
          </div>
        </div>
        <div className="footer-word">NyayAI</div>
        <div className="footer-bottom">
          <span>© 2026 NyayAI Technologies Pvt. Ltd. · Incorporated in Bengaluru</span>
          <span>v 0.9.2 · Private beta</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { Nav, Footer, Logo, LangRibbon, INDIAN_LANGS });
