// NyayAI — App shell (routing + tweaks)

const { useState, useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "gold",
  "serif": "instrument",
  "density": "cozy"
}/*EDITMODE-END*/;

const ACCENTS = {
  gold:   { '--gold': '#c9a96b', '--gold-dim': '#8a7548' },
  bone:   { '--gold': '#e5dccb', '--gold-dim': '#a09685' },
  ink:    { '--gold': '#f5f1e8', '--gold-dim': '#7a766c' },
  crimson:{ '--gold': '#c97a6b', '--gold-dim': '#8a5348' },
};

const SERIFS = {
  instrument: '"Instrument Serif", "Cormorant Garamond", "Times New Roman", serif',
  cormorant:  '"Cormorant Garamond", "Times New Roman", serif',
  fraunces:   '"Fraunces", "Times New Roman", serif',
};

function applyTweaks(t) {
  const root = document.documentElement;
  const a = ACCENTS[t.accent] || ACCENTS.gold;
  Object.entries(a).forEach(([k, v]) => root.style.setProperty(k, v));
  root.style.setProperty('--serif', SERIFS[t.serif] || SERIFS.instrument);
  document.body.style.fontSize = t.density === 'compact' ? '14px' : t.density === 'airy' ? '16px' : '15px';
}

function TweaksPanel({ tweaks, setTweaks, open, setOpen }) {
  return (
    <div className={`tweaks-panel ${open ? 'open' : ''}`}>
      <div className="tweaks-head">
        <span>Tweaks</span>
        <button onClick={() => setOpen(false)} style={{ color: 'var(--ink-3)', fontSize: 14 }}>×</button>
      </div>
      <div className="tweaks-body">
        <div className="tweak-row">
          <div className="tweak-label">Accent</div>
          <div className="tweak-opts">
            {Object.entries(ACCENTS).map(([k, v]) => (
              <div key={k} className={`tweak-swatch ${tweaks.accent === k ? 'active' : ''}`}
                style={{ background: v['--gold'] }}
                onClick={() => setTweaks(s => ({ ...s, accent: k }))} />
            ))}
          </div>
        </div>
        <div className="tweak-row">
          <div className="tweak-label">Serif</div>
          <div className="tweak-opts">
            {Object.keys(SERIFS).map(k => (
              <button key={k} className={`tweak-opt ${tweaks.serif === k ? 'active' : ''}`}
                onClick={() => setTweaks(s => ({ ...s, serif: k }))}>{k}</button>
            ))}
          </div>
        </div>
        <div className="tweak-row">
          <div className="tweak-label">Density</div>
          <div className="tweak-opts">
            {['compact', 'cozy', 'airy'].map(k => (
              <button key={k} className={`tweak-opt ${tweaks.density === k ? 'active' : ''}`}
                onClick={() => setTweaks(s => ({ ...s, density: k }))}>{k}</button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function App() {
  const [route, setRoute] = useState(() => {
    const saved = localStorage.getItem('nyayai-route');
    return saved || 'home';
  });
  const [tweaks, setTweaks] = useState(TWEAK_DEFAULTS);
  const [tweaksOpen, setTweaksOpen] = useState(false);

  useEffect(() => { applyTweaks(tweaks); }, [tweaks]);

  useEffect(() => {
    localStorage.setItem('nyayai-route', route);
    window.scrollTo(0, 0);
  }, [route]);

  useEffect(() => {
    window.navigate = (r) => setRoute(r);

    const handler = (e) => {
      if (!e.data) return;
      if (e.data.type === '__activate_edit_mode') setTweaksOpen(true);
      if (e.data.type === '__deactivate_edit_mode') setTweaksOpen(false);
    };
    window.addEventListener('message', handler);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', handler);
  }, []);

  useEffect(() => {
    window.parent.postMessage({ type: '__edit_mode_set_keys', edits: tweaks }, '*');
  }, [tweaks]);

  let Page = HomePage;
  if (route === 'features') Page = FeaturesPage;
  if (route === 'pricing') Page = PricingPage;
  if (route === 'about') Page = AboutPage;

  return (
    <div className="page" data-screen-label={route}>
      <Nav route={route} />
      <main key={route} style={{ flex: 1, animation: 'msgIn 0.4s ease' }}>
        <Page />
      </main>
      <Footer />
      <TweaksPanel tweaks={tweaks} setTweaks={setTweaks} open={tweaksOpen} setOpen={setTweaksOpen} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
