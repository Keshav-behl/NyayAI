// Shared layout primitives for NyayAI
// Exports: Nav, Footer, Brand, Icon, useRoute, navigate, LangRibbon

const { useState, useEffect, useRef, useMemo, useCallback } = React;

// --- Router ---
function useRoute() {
  const [route, setRoute] = useState(() => window.location.hash.replace('#', '') || '/');
  useEffect(() => {
    const onHash = () => {
      setRoute(window.location.hash.replace('#', '') || '/');
      window.scrollTo({ top: 0, behavior: 'instant' });
    };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  return route;
}

function navigate(path) {
  window.location.hash = path;
}

// --- Icon ---
function Icon({ name, size = 16, stroke = 1.5 }) {
  const common = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: stroke, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const paths = {
    arrow: <path d="M5 12h14M13 6l6 6-6 6" />,
    send: <><path d="M22 2L11 13" /><path d="M22 2l-7 20-4-9-9-4 20-7z" /></>,
    plus: <><path d="M12 5v14M5 12h14" /></>,
    check: <polyline points="20 6 9 17 4 12" />,
    sparkle: <><path d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/></>,
    scroll: <><path d="M7 4h10a2 2 0 012 2v12a3 3 0 003-3H8" /><path d="M3 4v15a3 3 0 003 3h11" /></>,
    shield: <path d="M12 2l9 4v6c0 5-3.5 9-9 10-5.5-1-9-5-9-10V6l9-4z" />,
    doc: <><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" /><polyline points="14 2 14 8 20 8" /><line x1="8" y1="13" x2="16" y2="13" /><line x1="8" y1="17" x2="14" y2="17" /></>,
    gavel: <><path d="M14 13l-7.5 7.5a2.1 2.1 0 01-3-3L11 10" /><path d="M16 16l6-6" /><path d="M8 8l6-6 6 6-6 6z" /></>,
    search: <><circle cx="11" cy="11" r="7" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></>,
    net: <><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18" /></>,
    close: <><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></>,
    slider: <><line x1="4" y1="7" x2="20" y2="7" /><circle cx="9" cy="7" r="2" fill="currentColor"/><line x1="4" y1="17" x2="20" y2="17" /><circle cx="15" cy="17" r="2" fill="currentColor"/></>,
  };
  return <svg {...common}>{paths[name] || paths.arrow}</svg>;
}

// --- Brand ---
function Brand({ onClick }) {
  return (
    <a href="#/" onClick={(e) => { e.preventDefault(); navigate('/'); onClick?.(); }} className="brand">
      <span className="brand-mark"><em>N</em></span>
      <span>Nyay<span style={{fontStyle:'italic', color:'var(--gold)'}}>AI</span></span>
      <span className="brand-sub">Legal · India</span>
    </a>
  );
}

// --- Nav ---
function Nav() {
  const route = useRoute();
  const links = [
    { label: 'Home', path: '/' },
    { label: 'Features', path: '/features' },
    { label: 'Pricing', path: '/pricing' },
    { label: 'About', path: '/about' },
  ];
  const isActive = (p) => route === p || (p === '/' && route === '');
  return (
    <nav className="nav">
      <div className="container-wide nav-inner">
        <Brand />
        <div className="nav-links">
          {links.map(l => (
            <a key={l.path} href={`#${l.path}`} className={`nav-link ${isActive(l.path) ? 'active' : ''}`}
               onClick={(e) => { e.preventDefault(); navigate(l.path); }}>
              {l.label}
            </a>
          ))}
          <div className="nav-cta">
            <a href="#/signin" className="nav-link">Sign in</a>
            <a href="#/pricing" onClick={(e)=>{e.preventDefault(); navigate('/pricing');}} className="btn btn-primary">
              Get access <Icon name="arrow" size={14} />
            </a>
          </div>
        </div>
      </div>
    </nav>
  );
}

// --- Language Ribbon (multilingual inclusivity) ---
function LangRibbon() {
  const words = [
    { text: 'न्याय', font: 'var(--deva)', label: 'Hindi' },
    { text: 'நீதி', font: 'var(--tamil)', label: 'Tamil' },
    { text: 'ন্যায়', font: 'var(--bengali)', label: 'Bengali' },
    { text: 'انصاف', font: 'var(--urdu)', label: 'Urdu' },
    { text: 'Justice', font: 'var(--serif)', label: 'English' },
    { text: 'न्याय', font: 'var(--deva)', label: 'Marathi' },
    { text: 'ನ್ಯಾಯ', font: 'var(--deva)', label: 'Kannada' },
    { text: 'ન્યાય', font: 'var(--deva)', label: 'Gujarati' },
    { text: 'ਨਿਆਂ', font: 'var(--deva)', label: 'Punjabi' },
    { text: 'ന്യായം', font: 'var(--deva)', label: 'Malayalam' },
    { text: 'న్యాయం', font: 'var(--deva)', label: 'Telugu' },
    { text: 'ନ୍ୟାୟ', font: 'var(--deva)', label: 'Odia' },
  ];
  const all = [...words, ...words];
  return (
    <div className="lang-ribbon" aria-label="Languages supported">
      <div className="lang-ribbon-track">
        {all.map((w, i) => (
          <span key={i} className="lang-word">
            <span style={{ fontFamily: w.font }}>{w.text}</span>
            <span className="mono">· {w.label}</span>
          </span>
        ))}
      </div>
    </div>
  );
}

// --- Footer ---
function Footer() {
  return (
    <footer className="footer">
      <div className="container-wide">
        <div className="footer-grid">
          <div className="footer-col">
            <Brand />
            <p className="footer-brand-p">
              India's legal operating system. Built on a RAG architecture grounded in
              Indian statutes, case law and the workflows of working lawyers.
            </p>
            <div className="footer-langs" title="Languages in development">
              <span style={{fontFamily:'var(--deva)'}}>न्याय</span>
              <span style={{fontFamily:'var(--tamil)'}}>நீதி</span>
              <span style={{fontFamily:'var(--bengali)'}}>ন্যায়</span>
              <span style={{fontFamily:'var(--urdu)'}}>انصاف</span>
            </div>
          </div>
          <div className="footer-col">
            <h4>Product</h4>
            <a href="#/features" onClick={(e)=>{e.preventDefault(); navigate('/features');}}>Features</a>
            <a href="#/pricing" onClick={(e)=>{e.preventDefault(); navigate('/pricing');}}>Pricing</a>
            <a href="#/">AI Assistant</a>
            <a href="#/">Drafting</a>
            <a href="#/">Compliance</a>
          </div>
          <div className="footer-col">
            <h4>Company</h4>
            <a href="#/about" onClick={(e)=>{e.preventDefault(); navigate('/about');}}>About</a>
            <a href="#/">Research</a>
            <a href="#/">Careers</a>
            <a href="#/">Press</a>
          </div>
          <div className="footer-col">
            <h4>Resources</h4>
            <a href="#/">Documentation</a>
            <a href="#/">API</a>
            <a href="#/">Security</a>
            <a href="#/">Changelog</a>
          </div>
          <div className="footer-col">
            <h4>Legal</h4>
            <a href="#/">Terms</a>
            <a href="#/">Privacy</a>
            <a href="#/">Disclaimer</a>
            <a href="#/">DPDP compliance</a>
          </div>
        </div>
        <div className="footer-word">NyayAI.</div>
        <div className="footer-bottom">
          <span>© 2026 NyayAI Technologies · New Delhi · Bangalore</span>
          <span>v0.9 · beta · made in india</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { useRoute, navigate, Icon, Brand, Nav, Footer, LangRibbon });
